#include <iostream>
//allows me to use cout, cin, endl ect
#include "list.h"
//allows me to use the funcs, classes, and stuct in the list header file
using namespace std;
// not have to use std::

list::list(string n, string g, int a){
  //definig list constuctor
name = n;
//assigning the string varible from the parameters to the name varible in the list object
grade = g;
//assigning the string varible from the parameters to the grade varible in the list object
age = a;
//assigning the int varible from the parameters to the age varible in the list object
sptr = NULL;
//setting the pointer variable to NULL

}

list::llstudent(int num, student wen){
  //defining the student list function
  student* one = wen;
  //asking the user for their
  student* two = one;
//setting the "two" variable to the value in "one" (the memory location of the first student object) 
  
  
    for(int x = 1; x<= num; x++){
      //for loop to create the list
      two -> sprt = new student;
      //creating a new student object and storing it's memory location in the last student objects ptr
      two = two -> sprt;
      //setting the two variable to the memory location of the new student in the sprt variable 
    }
  two = one;
  //setting 
}

list::llprint(student* cur){
  //defining the pring function
while(cur != NULL){
  //while loop to run through the linked list
cout<< cur -> name<<endl;
//printing the name in the variabe at the cur memory location
cout<< cur -> gender<<endl;
//printing the name in the variabe at the cur memory location
cout<< cur -> age<<endl;
//printing the name in the variabe at the cur memory location
cur = cur -> sptr
//setting the cur ptr to the location of the next student
}
}

list::delellstu(){

}
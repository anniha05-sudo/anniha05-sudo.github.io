#include <iostream>
//
using namespace std;
//

struct siblings{
  //declares the sibling struct
  string name;
  //creates name variable
  string gender;
  //creates gender variable
  int age;
  //creates age variable
  siblings* sptr;
  //creates a variable that stores the memory location
}

class list{
//declares list class

list(string n, string g, int a);
void llstudent();
void llprint();
void delellstu();

}


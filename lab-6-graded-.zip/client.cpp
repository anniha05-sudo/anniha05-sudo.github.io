#include <iostream>
//allows me to use cout, cin, endl ect
#include "list.h"
//allows me to use the funcs, classes, and stuct in the list header file
using namespace std;
// not have to use std::

int main(){
  //declares main function
  int sibnum;
  //crates the sibling number variable
  string name;
  //creats the user name variable
  int age;
  //creates the user age variable

  cout<<"Enter your name"<<endl;
  //asks the user for their name
  cin>>name;
  //stores user input in the name variable
  cout<<"Enter your age"<<endl;
  //asks the user for their age
  cin>>age;
  //stores the user input int the name variable


cout<<"How many siblings do you have?"<<endl;
//ask the the user for the number of sibling they have
cin>>sibnum>>;
//stores the user input in the sibnum variable


}
# -*- coding: utf-8 -*-
"""
Created on Mon May  4 14:02:10 2026

@author: annih

Project 7 - hawk-Dove Evolutionary Game
EECE 260 - Spring 2026
"""

import numpy as np
import matplotlib.pyplot as plt

# step 1 fitness of hws and dvs
def fit_Hawk(x, v, c):
    # eqution for fitness of hawks
    return x * (v-c)/2.0 + (1.0 - x) * v
# returns expected payoff for a Hawk

def fit_Dove(x,v):
    # equation for fitness of doves
    return (1.0 - x) * (v / 2.0)
# returns expected payoff for a Dove.

# step 2 replicator equation
def xdot(t, x, v, c):
    # Replicator rate
    return x*(1.0-x)*(fit_Hawk(x,v,c) - fit_Dove(x,v))
# returns the instantaneous rate of change of x

def xdot_scalar(x, v, c):
    return xdot(0.0, x, v, c)
# returns scalar version of xdot needed for newt func

# step 3 deriv of xdot 
def dx_xdot(x, v, c):
    u = x*(1.0 - x)
    V = v - c * x
    up = 1.0 - 2.0 *x
    Vp = -c
    return 0.5 * (up * V + u * Vp)
# returns slope of xdot at x
# used in newtons methd and for stability check

# step 4 Euler and RK4
def euler(f, t, y, h, *args):
    dy = f(t, y, *args)
    return y + h * dy

def rk4(f, t, y, h, *args):
    k1 = f(t, y, *args)
    k2 = f(t + 0.5 * h, y + 0.5 * h * k1, *args)
    k3 = f(t + 0.5 * h, y + 0.5 * h * k2, *args)
    k4 = f(t + h, y + h * k3, *args)
    return y + (h/6.0) * (k1 + 2.0 * k2 +2.0 * k3 + k4)
# higher accuracy than euler and used for bonus

# step 5 sim 
def sim(method, x0, t0, tl, h, v, c ):
    #Simulates x(t) from t0 to tl
    n = int(np.floor((tl-t0)/h))+1
    t_vals = np.linspace(t0, t0 + h *(n-1),n)
   # t_vals = array of time points
    x_vals = np.zeros_like(t_vals)
    #x_vals = array of x(t) values at each time
    x_vals[0] = x0
   
    if method == 'euler':
        func = euler
    elif method == "rk4":
        func = rk4
    else:
        raise ValueError("Method not found. Chose euler or rk4")
    for i in range(n - 1):
        t = t_vals[i]
        x = x_vals[i]
        x_next = func(xdot,t,x,h,v,c)
        x_vals[i + 1] = min(max(x_next,0.0),1.0)
        
    return t_vals, x_vals 
# returns arrays used for plots, stablity, and heatmap

# step 6 newtons method task 3

def newt_root(f, df, x0, v, c, tol=1e-10, max_iter=50):
    # newtons method
    x =x0
    #solves f(x) = 0
    for i in range(max_iter):
        fx = f(x, v, c)
        dfx = df(x, v, c)
        if abs(dfx)<1e-14:
            return x, False
        x_new = x - fx/dfx
        if abs(x_new - x) < tol:
            return x_new, True
        x=x_new
        #boolean checks if Newton failed.
    return x, False

# step 7 task 4
def stability(x_equilib, v, c):
    #Classifies stability of an equilibrium
    m = dx_xdot(x_equilib, v, c)
   
    if m < 0 :
        return "Stable", m
   
    elif m > 0:
        return "Unstable", m
   
    else:
        return "Neutral", m
# Step 8 heatmap task 5
def param_reg(v, c, tl=50.0, h=0.05):
    # three starting points to test the dynamics
    x0 = [0.1, 0.5, 0.9]
    val_final = []
    # simulate from each initial condition
    for x in x0:
        _,x_vals = sim('euler', x, 0.0, tl, h, v,c)
        val_final.append(x_vals[-1])
     # convert to array for easy comparisons
    val_final = np.array(val_final)
    eps = 1e-2
    
    dove = np.all(val_final<eps)
    hawk = np.all(val_final > 1.0 -eps)
    # classify 
    if dove:
        return 0
    if hawk:
        return 1
    if np.max(val_final)<1.0 - eps and np.min(val_final) > eps:
        if np.max(val_final) - np.min(val_final) < 0.05:
            return 2
    return 3
"""Returns,
      0 if all Dove
      1 if all Hawk
      2 if mixed ESS
      3 if pathological"""
      
def build_HM():
    #Builds the heatmap grid
    vals_v = np.linspace(0.5, 5.0, 100)
    #array of V values (x-axis)
    vals_c = np.linspace(0.5, 10.0, 60)
    #array of C values (y-axis)
    grid = np.zeros((len(vals_c), len(vals_v)), dtype=int)
    
    for i, c in enumerate(vals_c):
        for j, v in enumerate(vals_v):
            grid[i,j] = param_reg(v,c)
    return vals_v, vals_c, grid

# step 9 plotting
def plot_HM(vals_v, vals_c, grid):
    plt.figure(figsize=(7,5))
    im = plt.imshow(grid, origin='lower',
        extent=[vals_v[0], vals_v[-1], vals_c[0], vals_c[-1]],
        aspect='auto', cmap='tab10')
    
    cbar=plt.colorbar(im)
    cbar.set_ticks([0,1,2,3])
    cbar.set_ticklabels(['All Dove', 'All Hawk', 'mixed ESS', 'pathological'])
    
    plt.xlabel("V (Contested Resource Value)")
    plt.ylabel("C (Hawk on Hawk Fight Cost of Injury)")
    plt.title("Regimes")
    plt.tight_layout()

def x_t(res, v, c):
    plt.figure(figsize=(8,5))
    for r in res:
        label = f"{r['method'].upper()},x0={r['x0']:.2f}"
        plt.plot(r['t'], r['x'], label=label)
    plt.axhline(v/c, color='k', linestyle='--', label='ESS x* = V/C')
    plt.xlabel("Time")
    plt.ylabel("Fraction of Hawks x(t)")
    plt.title(f"Hawk-Dove Replicator (v={v}, c={c})")
    plt.ylim(-0.05, 1.05)
    plt.grid(True)
    plt.legend()
    plt.tight_layout()

def plt_dxdt(v,c,points=200):
    vals_x = np.linspace(0.0, 1.0, points)
    vals_dxdt = np.array([xdot_scalar(x,v,c)for x in vals_x])
    
    plt.figure(figsize=(8,4))
    plt.axhline(0.0, color='k', linewidth=1)
    plt.plot(vals_x, vals_dxdt, label="dx/dt")
   
    plt.xlabel("x (fraction of hawks)")
    plt.ylabel("dx/dt")
    plt.title(f"Phase Line for Hawk-Dove Evolutionary Game(v={v}, c={c})")
    
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    
"""Three-strategy extension (bonus):"""
def three_strat_payoffs(x, v, c):
    # hawkx = fraction Hawks, dovex = fraction Doves, xbar = fraction Bourgeois
    hawkx, dovex, xbar = x
    #Computes fitness for Hawk, Dove, and Bourgeois
    HawkH = (v-c) / 2.0 # two Hawk fight  expected payoff
    HawkD = v # Hawk always beats Dove
    HawkB = (3.0*v-c)/4.0 # Hawk vs Bourgeois
    
    DoveH = 0.0 # Dove retreats vs Hawk
    DoveD = v/2.0 # Dove splits resource with Dove
    DoveB = v/4.0 # Dove vs Bourgeois
    
    BarH = (v-c)/4.0 # Bourgeois vs Hawk
    BarD = 3.0 * v/4.0 # Bourgeois vs Dove
    BarB = v/2.0 # Bourgeois splits with Bourgeois
    
    """Expected fitness for each strategy.
   Multiply each payoff by the probability"""
    funcH = HawkH * hawkx + HawkD * dovex + HawkB * xbar
    funcD = DoveH * hawkx + DoveD * dovex + DoveB * xbar 
    funcB = BarH * hawkx + BarD * dovex + BarB * xbar
    
    # Average fitness of the whole population
    f_bar = hawkx * funcH + dovex * funcD + xbar * funcB
    
    # returns an array of the 3 fitness values and ave fit of pop
    return np.array([funcH, funcD, funcB]), f_bar

def xdot_3strat(t, x, v, c):
    f_vec, f_bar = three_strat_payoffs(x, v, c)
    #array of 3 fitness values
    return x * (f_vec - f_bar)

def sim_3strat(x0, t0, t_end, h, v, c):
    n = int(np.floor((t_end-t0)/h))+1
    vals_t = np.linspace(t0, t0+h *(n-1),n)
    vals_x = np.zeros((n,3))
    vals_x[0,:] = x0
    
    for i in range(n-1):
        t = vals_t[i]
        x = vals_x[i,:]
        x = np.clip(x, 0.0, 1.0)
        s = x.sum()
        
        if s>0:
            x = x/s
        x_next = rk4(xdot_3strat, t, x, h, v,c)
        vals_x[i+1,:] = x_next
        
    return vals_t,vals_x

def plot_3strat(vals_t, vals_x):
    plt.figure(figsize=(8,5))
    plt.plot(vals_t, vals_x[:,0], label="Hawk(H)")
    plt.plot(vals_t, vals_x[:,1], label="Dove(D)")
    plt.plot(vals_t, vals_x[:,2], label="Bourgeois(B)")
    plt.xlabel("Time")
    plt.ylabel("Strategy Frequency")
    plt.title("Three-Strategy Bourgeois: H, D, B")
    plt.ylim(-0.05, 1.05)
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    
#step 10 main function

def main():
    # parameters from the project doc
    v = 2.0
    c = 6.0 
    
    # time settings for the ODE simulation
    t0 = 0.0 
    t_end = 30.0 
    h = 0.01
    
    initial_conditions = [0.05, 0.3, 0.5, 0.8, 0.95]
    #euler used here, rk4 for bonus
    method = ['euler']
    # store results for plotting
    results = []
    
    # simulate x(t) for each value
    for x0 in initial_conditions:
        for m in method:
            vals_t, vals_x = sim(m, x0, t0, t_end, h, v, c)
            results.append({'t':vals_t, 'x':vals_x, 'method':m, 'x0':x0})
            
    #1
    x_t(results, v, c)
    #2
    plt_dxdt(v,c)
    #3 checks
    print("Newton's Method for equilibrium")
    guess = [0.0 + 1e-3, 1.0-1e-3, v/c+0.1]
    for g in guess:
        root, conv = newt_root(xdot_scalar, dx_xdot, g, v, c)
        print(f"initial guess{g:.4f}->root{root:.6f},converged={conv}")
        
    #4
    print(" Stability Analysis")
    print()
    points = [0.0, 1.0, v/c]
    for x in points:
        stabil, slope = stability(x, v, c)
        print(f"x = {x:.6f}, dx_xdot = {slope:.6f},{stabil}")
        
    #5   
    print(" Numerical Stability")
    print()
    x_star = v/c
    for delta in [-0.05, 0.05]:
        x0= x_star + delta
        vals_t, vals_x = sim('euler', x0,t0, t_end, h, v, c)
        print(f"x0=x*{x_star:.4f}+{delta:+.2f}->x(t)={vals_x[-1]:.6f}")

    #6
    print(" Building(v,c heatmap")
    print()
    vals_v, vals_c, grid=build_HM()
    plot_HM(vals_v , vals_c, grid)
    
    print(" Three strategy system")
    print()
    x0=np.array([0.4, 0.4, 0.2])
    t_vals, x_vals = sim_3strat(x0, 0.0, 50.0, 0.01, v, c)
    plot_3strat(t_vals, x_vals)
    
    print(f"Final frequencies at t = {t_vals[-1]:.1f}:{x_vals[-1,:]}")
    
    plt.show()
    
if __name__=="__main__":
        main()